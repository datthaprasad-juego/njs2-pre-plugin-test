class JoinRandomRoomAction extends baseAction {
  async executeMethod() {
    try {
      let { userObj, roomType } = this;

      //temp user_id array of length 100 and update userObj with random user_id data
      let tempUserArray = [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19,
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28,
        29,
        30,
        31,
        32,
        33,
        34,
        35,
        36,
        37,
        38,
        39,
        40,
        41,
        42,
        43,
        44,
        45,
        46,
        47,
        48,
        49,
        50,
        51,
        52,
        53,
        54,
        55,
        56,
        57,
        58,
        59,
        60,
        61,
        62,
        63,
        64,
        65,
        66,
        67,
        68,
        69,
        70,
        71,
        72,
        73,
        74,
        75,
        76,
        77,
        78,
        79,
        80,
        81,
        82,
        83,
        84,
        85,
        86,
        87,
        88,
        89,
        90,
        91,
        92,
        93,
        94,
        95,
        96,
        97,
        98,
        99,
        100,
      ];
      userObj = {
        user_id:
          tempUserArray[Math.floor(Math.random() * tempUserArray.length)],
      };
      let roomTempArray = [1, 2, 3];
      roomType =
        roomTempArray[Math.floor(Math.random() * roomTempArray.length)];

      //Variable section
      let waitinUserdetails;

      /*<----------- FIND WAITING USER ----------->*/
      {
        waitinUserdetails = await SQLManager.findOne("waiting_user", {
          user_id: userObj.user_id,
        });
      }

      /*<------------ CREATE USER IF NOT IN WAITING USERS ------------>*/
      {
        if (!waitinUserdetails) {
          await SQLManager.insert("waiting_user", {
            user_id: userObj.user_id,
            room_type: roomType,
            waiting_start_time: Date.now() / 1000,
            waiting_end_time: Date.now() / 1000 + GLB.MAX_WAITING_TIME,
          });
        }
      }

      /*<------------ IF USER ALREADY PLAYING (ALREADY ROOM USER), WARN USER ------------>*/
      {
        if (waitinUserdetails && waitinUserdetails.status === GLB.ROOM_USER) {
          return {
            user_id: userObj.user_id,
            error: "You are already playing",
          };
        }
      }

      /*<------------ UPDATE USER IF ALREADY IN WAITING USERS QUEUE AND NOT PLAYING ANY GAME ------------>*/
      {
        await SQLManager.update(
          "waiting_user",
          {
            user_id: userObj.user_id,
          },
          {
            status: GLB.ACTIVE,
            room_type: roomType,
            waiting_start_time: Date.now() / 1000,
            waiting_end_time: Date.now() / 1000 + GLB.MAX_WAITING_TIME,
          }
        );
      }

      this.setResponse("SUCCESS");
      return {};
    } catch (error) {
      console.log(error);
      return error.message;
    }
  }
}
module.exports = JoinRandomRoomAction;
