/* eslint-disable-next-line no-unused-vars */
module.exports = async (roomObj) => {

};