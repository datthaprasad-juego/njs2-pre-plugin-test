const STRING = {
  PROJECT_MSG: "Welcome to Njs2 framework project"
};

module.exports.STRING = STRING;