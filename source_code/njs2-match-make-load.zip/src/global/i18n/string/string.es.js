const STRING = {
  PROJECT_MSG: "Bienvenido al proyecto marco de Njs2"
};

module.exports.STRING = STRING;