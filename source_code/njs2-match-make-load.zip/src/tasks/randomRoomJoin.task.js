AutoLoad = require("@njs2/base/base/autoload.class");
AutoLoad.loadConfig();
AutoLoad.loadModules();
const handler = async () => {
  try {
    let user = await SQLManager.findOne(
      "waiting_user",
      {
        status: GLB.ACTIVE,
        room_type: GLB.ROOM_TYPES_ARRAY[0],
      },
      { waiting_end_time: 1 }
    );

    console.log({user});

    GLB.ROOM_TYPES_ARRAY.push(
      GLB.ROOM_TYPES_ARRAY.shift()
    );


    //if no waiting user in queue
    if (!user) return 1;

    //If waiting time is over update status
    if (user.waiting_end_time < Date.now() / 1000) {
      await SQLManager.update(
        "waiting_user",
        {
          user_id: user.user_id,
        },
        {
          status: GLB.INACTIVE,
        }
      );
    } else {
      let roomUsers = (
        await SQLManager.doExecuteRawQuery(
          `SELECT * FROM waiting_user
        WHERE status=${GLB.ACTIVE}
        AND room_type=${user.room_type} 
        AND user_id!=${user.user_id}
        ORDER BY waiting_start_time ASC
        LIMIT ${GLB.ROOM_CONDITION_TYPE[user.room_type].MAXIMUM_PLAYER - 1}`
        )
      )[0];

      if (
        roomUsers.length ===
        GLB.ROOM_CONDITION_TYPE[user.room_type].MAXIMUM_PLAYER - 1
      ) {
        //create new room
        let roomId = await SQLManager.insert(
          "room",
          {
            room_type: user.room_type,
          },
          {},
          ["room_id"]
        );

        //add user to roomUsers list
        roomUsers.push(user);

        //add room users in DB
        await SQLManager.doExecuteRawQuery(`
          INSERT INTO room_user (room_id, user_id)
          VALUES ${roomUsers
            .map((user) => `(${roomId}, ${user.user_id})`)
            .join(",")}
          `);

        //update waiting users
        await SQLManager.doExecuteRawQuery(`
                UPDATE waiting_user
                SET status=${GLB.ROOM_USER}
                WHERE user_id IN (${roomUsers
                  .map((user) => user.user_id)
                  .join(",")})
            `);
      }
    }
    return 1;
  } catch (e) {
    console.log(e);
    return 0;
  }
};
module.exports = handler;
